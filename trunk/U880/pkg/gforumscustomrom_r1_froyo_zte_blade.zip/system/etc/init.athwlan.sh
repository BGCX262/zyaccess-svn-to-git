#!/system/bin/sh
chmod 750 /system/wifi/*.sh
setprop wlan.default.dns1 168.95.1.1
setprop wifi.interface wlan0
